# Mural Horizonte Escola

## Organização

- `public/`: `rafa.html` (login), `mural.html`, termos e recursos visuais.
- `src/routes/`: rotas HTTP da aplicação.
- `src/database/`: acesso ao SQLite e operações de dados.
- `data/`: banco SQLite local, criado automaticamente.
- `tests/`: testes de API e banco de dados.
- `archive/`: arquivos antigos mantidos fora do funcionamento do sistema.

## Executar

Na pasta raiz do projeto, instale as dependências e inicie o servidor:

```sh
npm install
npm start
```

Abra `http://localhost:3120/mural/`.
Os endereços `rafa.html` e `rafa1.html` continuam funcionando; `login.html`
também é mantido como atalho para o login.

Para demonstração, use `nome@professor.edu.pi.gov.br` com a senha `5678` no
perfil de professor(a), ou `nome@aluno.edu.pi.gov.br` com a senha `1234` no
perfil de aluno.

Os avisos são armazenados em SQLite em `data/mural.db`, criado automaticamente
na primeira inicialização. Um banco existente no caminho antigo é copiado para
o novo local automaticamente. A API disponibiliza operações GET, POST, PUT e
DELETE em `/api/avisos`. Consulte `/api/health` para confirmar que o banco está
conectado. Eventos adicionados pelo(a) professor(a) em “Próximos dias” são
armazenados no mesmo banco SQLite e ficam disponíveis em `/api/eventos`.
No login, o(a) professor(a) escolhe se é professor(a) de disciplina ou do curso.
Para professor(a) de disciplina, informa uma ou mais matérias; para professor(a)
do curso, essa informação não é solicitada. Todas selecionam os cursos em que
lecionam (turmas/cursos) e as séries em que atuam; essas escolhas ficam salvas no perfil pelo
e-mail e aparecem em “Minha conta”. Ao publicar um aviso, só aparecem as
combinações de curso e série vinculadas, e a API também recusa destinatários
fora do perfil. Avisos antigos, sem destinatário definido, continuam visíveis
para todos. Os cursos disponíveis são Desenvolvimento de Sistemas, Alimentos
e Farmácia, e as séries são 1º, 2º e 3º ano.

## Testar o banco de dados

Execute `npm test` na pasta raiz. Além das verificações de sintaxe, os testes de
integração usam um banco SQLite temporário para confirmar a conexão, as
operações da API de avisos e a criação, consulta e remoção de eventos do
calendário, sem alterar o banco usado pela aplicação.