import sqlite3

# Isso cria o arquivo database.db automaticamente na mesma pasta
conexao = sqlite3.connect('database.db')
print("Banco de dados criado com sucesso!")
conexao.close()
