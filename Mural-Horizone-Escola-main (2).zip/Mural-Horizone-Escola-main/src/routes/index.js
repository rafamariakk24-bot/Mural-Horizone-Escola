const express = require('express');
const router = express.Router();
const mural = require('../database/mural');
const calendario = require('../database/calendario');
const professores = require('../database/professores');

const requiredTextFields = ['title', 'content', 'author', 'category'];
const assessmentCategories = ['Prova', 'ENEM', 'Vestibular', 'Simulado'];
const noticeSeries = ['1º ano', '2º ano', '3º ano'];
const noticeCourses = ['Desenvolvimento de Sistemas', 'Alimentos', 'Farmácia'];

router.get('/api/health', async (req, res, next) => {
  try {
    await mural.checkDatabase();
    res.json({ status: 'ok', database: 'connected' });
  } catch (error) {
    next(error);
  }
});

function validateNotice(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return 'O corpo da requisição deve ser um objeto JSON.';
  }

  for (const field of requiredTextFields) {
    if (typeof body[field] !== 'string' || !body[field].trim()) {
      return `O campo "${field}" é obrigatório.`;
    }
  }

  if (
    assessmentCategories.includes(body.category) &&
    (typeof body.subject !== 'string' || !body.subject.trim())
  ) {
    return 'Informe os conteúdos que serão cobrados na avaliação.';
  }

  if (!Array.isArray(body.audience) || body.audience.length < 1) {
    return 'Selecione uma ou mais combinações de série e curso para o aviso.';
  }
  const audienceKeys = body.audience.map(target => (
    target && typeof target === 'object'
      ? `${target.serie}::${target.turma}`
      : ''
  ));
  if (
    body.audience.some(target => (
      !target ||
      typeof target !== 'object' ||
      !noticeSeries.includes(target.serie) ||
      !noticeCourses.includes(target.turma)
    )) ||
    new Set(audienceKeys).size !== audienceKeys.length
  ) {
    return 'Selecione combinações válidas e sem repetição de série e curso.';
  }

  if (
    body.title.length > 70 ||
    body.content.length > 240 ||
    (body.teacherEmail !== undefined && typeof body.teacherEmail !== 'string') ||
    (body.teacherSubject !== undefined && typeof body.teacherSubject !== 'string') ||
    (body.teacherSubject?.length || 0) > 200 ||
    (body.subject !== undefined && typeof body.subject !== 'string') ||
    (body.subject?.length || 0) > 180 ||
    (body.dueDate !== undefined && typeof body.dueDate !== 'string') ||
    (body.pinned !== undefined && typeof body.pinned !== 'boolean')
  ) {
    return 'Um ou mais campos excedem o limite de caracteres.';
  }

  if (body.attachment && (
    typeof body.attachment !== 'object' ||
    typeof body.attachment.name !== 'string' ||
    typeof body.attachment.type !== 'string' ||
    typeof body.attachment.data !== 'string'
  )) {
    return 'O anexo enviado é inválido.';
  }

  return null;
}

function parseNoticeId(value) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function validateCalendarEvent(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return 'O corpo da requisição deve ser um objeto JSON.';
  }

  if (typeof body.title !== 'string' || !body.title.trim()) {
    return 'O título do evento é obrigatório.';
  }

  if (body.title.length > 70) {
    return 'O título do evento deve ter no máximo 70 caracteres.';
  }

  if (typeof body.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(body.date)) {
    return 'Informe uma data válida para o evento.';
  }

  const parsedDate = new Date(`${body.date}T00:00:00.000Z`);
  if (Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== body.date) {
    return 'Informe uma data válida para o evento.';
  }

  if (body.time !== undefined && (typeof body.time !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.time))) {
    return 'Informe um horário válido para o evento.';
  }

  if (body.location !== undefined && (typeof body.location !== 'string' || body.location.length > 100)) {
    return 'O local deve ter no máximo 100 caracteres.';
  }

  return null;
}

function parseEventId(value) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function parseProfessorEmail(value) {
  const email = value.trim().toLowerCase();
  return /^[^@\s]+@professor\.edu\.pi\.gov\.br$/.test(email) ? email : null;
}

async function validateTeacherAudience(body) {
  if (!body.teacherEmail) return null;

  const email = parseProfessorEmail(body.teacherEmail);
  if (!email) return 'O e-mail do(a) professor(a) é inválido.';

  const courses = await professores.getCourses(email);
  if (!courses.length) {
    return 'Selecione seus cursos no login antes de publicar avisos.';
  }
  const series = await professores.getSeries(email);
  if (!series.length) {
    return 'Selecione as séries em que leciona no login antes de publicar avisos.';
  }
  if (body.audience.some(target => !courses.includes(target.turma))) {
    return 'Você só pode publicar avisos para os cursos vinculados ao seu perfil.';
  }
  if (body.audience.some(target => !series.includes(target.serie))) {
    return 'Você só pode publicar avisos para as séries vinculadas ao seu perfil.';
  }

  return null;
}

router.get('/api/professores/:email/materia', async (req, res, next) => {
  const email = parseProfessorEmail(req.params.email);
  if (!email) return res.status(400).json({ error: 'O e-mail do perfil do(a) professor(a) é inválido.' });

  try {
    res.json({ email, subject: await professores.getSubject(email) });
  } catch (error) {
    next(error);
  }
});

router.put('/api/professores/:email/materia', async (req, res, next) => {
  const email = parseProfessorEmail(req.params.email);
  if (!email) return res.status(400).json({ error: 'O e-mail do perfil do(a) professor(a) é inválido.' });

  const subject = req.body?.subject;
  if (typeof subject !== 'string' || subject.trim().length > 200) {
    return res.status(400).json({ error: 'A matéria deve ter até 200 caracteres.' });
  }

  if (!subject.trim()) {
    try {
      res.json(await professores.saveSubject(email, ''));
    } catch (error) {
      next(error);
    }
    return;
  }

  const seenSubjects = new Set();
  const subjects = subject.split(',').map(item => item.trim()).filter(item => {
    const normalized = item.toLocaleLowerCase('pt-BR');
    if (!item || seenSubjects.has(normalized)) return false;
    seenSubjects.add(normalized);
    return true;
  });
  if (!subjects.length || subjects.some(item => item.length > 80)) {
    return res.status(400).json({ error: 'Cada matéria deve ter entre 1 e 80 caracteres.' });
  }

  try {
    res.json(await professores.saveSubject(email, subjects.join(', ')));
  } catch (error) {
    next(error);
  }
});

router.get('/api/professores/:email/cursos', async (req, res, next) => {
  const email = parseProfessorEmail(req.params.email);
  if (!email) return res.status(400).json({ error: 'O e-mail do perfil do(a) professor(a) é inválido.' });

  try {
    res.json({ email, courses: await professores.getCourses(email) });
  } catch (error) {
    next(error);
  }
});

router.put('/api/professores/:email/cursos', async (req, res, next) => {
  const email = parseProfessorEmail(req.params.email);
  if (!email) return res.status(400).json({ error: 'O e-mail do perfil do(a) professor(a) é inválido.' });

  const { courses } = req.body || {};
  if (
    !Array.isArray(courses) ||
    courses.length < 1 ||
    courses.some(course => !noticeCourses.includes(course)) ||
    new Set(courses).size !== courses.length
  ) {
    return res.status(400).json({ error: 'Selecione um ou mais cursos válidos, sem repetir.' });
  }

  try {
    res.json(await professores.saveCourses(email, courses));
  } catch (error) {
    next(error);
  }
});

router.get('/api/professores/:email/series', async (req, res, next) => {
  const email = parseProfessorEmail(req.params.email);
  if (!email) return res.status(400).json({ error: 'O e-mail do perfil do(a) professor(a) é inválido.' });

  try {
    res.json({ email, series: await professores.getSeries(email) });
  } catch (error) {
    next(error);
  }
});

router.put('/api/professores/:email/series', async (req, res, next) => {
  const email = parseProfessorEmail(req.params.email);
  if (!email) return res.status(400).json({ error: 'O e-mail do perfil do(a) professor(a) é inválido.' });

  const { series } = req.body || {};
  if (
    !Array.isArray(series) ||
    series.length < 1 ||
    series.some(serie => !noticeSeries.includes(serie)) ||
    new Set(series).size !== series.length
  ) {
    return res.status(400).json({ error: 'Selecione uma ou mais séries válidas, sem repetir.' });
  }

  try {
    res.json(await professores.saveSeries(email, series));
  } catch (error) {
    next(error);
  }
});

router.get('/api/avisos', async (req, res, next) => {
  const { role, serie } = req.query;
  if (role !== undefined && !['aluno', 'professor'].includes(role)) {
    return res.status(400).json({ error: 'O perfil informado é inválido.' });
  }
  if (role === 'aluno' && (!noticeSeries.includes(serie) || !noticeCourses.includes(req.query.turma))) {
    return res.status(400).json({ error: 'Informe sua série e curso para visualizar os avisos.' });
  }

  try {
    res.json(await mural.list(
      role === 'aluno' ? serie : undefined,
      role === 'aluno' ? req.query.turma : undefined
    ));
  } catch (error) {
    next(error);
  }
});

router.get('/api/eventos', async (req, res, next) => {
  try {
    res.json(await calendario.list());
  } catch (error) {
    next(error);
  }
});

router.post('/api/eventos', async (req, res, next) => {
  const validationError = validateCalendarEvent(req.body);
  if (validationError) return res.status(400).json({ error: validationError });

  try {
    res.status(201).json(await calendario.create(req.body));
  } catch (error) {
    next(error);
  }
});

router.delete('/api/eventos/:id', async (req, res, next) => {
  const id = parseEventId(req.params.id);
  if (!id) return res.status(400).json({ error: 'O identificador do evento é inválido.' });

  try {
    const deleted = await calendario.remove(id);
    if (!deleted) return res.status(404).json({ error: 'Evento não encontrado.' });
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

router.post('/api/avisos', async (req, res, next) => {
  const validationError = validateNotice(req.body);
  if (validationError) return res.status(400).json({ error: validationError });

  try {
    const audienceError = await validateTeacherAudience(req.body);
    if (audienceError) return res.status(403).json({ error: audienceError });
    res.status(201).json(await mural.create(req.body));
  } catch (error) {
    next(error);
  }
});

router.put('/api/avisos/:id', async (req, res, next) => {
  const id = parseNoticeId(req.params.id);
  if (!id) return res.status(400).json({ error: 'O identificador do aviso é inválido.' });

  const validationError = validateNotice(req.body);
  if (validationError) return res.status(400).json({ error: validationError });

  try {
    const audienceError = await validateTeacherAudience(req.body);
    if (audienceError) return res.status(403).json({ error: audienceError });
    const notice = await mural.update(id, req.body);
    if (!notice) return res.status(404).json({ error: 'Aviso não encontrado.' });
    res.json(notice);
  } catch (error) {
    next(error);
  }
});

router.delete('/api/avisos/:id', async (req, res, next) => {
  const id = parseNoticeId(req.params.id);
  if (!id) return res.status(400).json({ error: 'O identificador do aviso é inválido.' });

  try {
    const deleted = await mural.remove(id);
    if (!deleted) return res.status(404).json({ error: 'Aviso não encontrado.' });
    res.status(204).end();
  } catch (error) {
    next(error);
  }
});

router.use((error, req, res, next) => {
  console.error('Erro na API do mural:', error);
  if (res.headersSent) return next(error);
  res.status(500).json({ error: 'Ocorreu um erro interno ao processar o aviso.' });
});

module.exports = router;