
const router = require('express').Router();

// get post put delete

router.get("/atendimento", (req, res) => {
  res.send("chegou a atividade de atendimento");
});

router.post("/atendimento", (req, res) => {
    res.send("chegou a atividade de atendimento");
});

router.put("/atendimento/:id", (req, res) => {
    const {id} = req.params;
    res.send("chegou a atividade estamos atualizando o atendimento");
});

router.delete("/atendimento/:id", (req, res) => {
    const {id} = req.params;    
    res.send("chegou a atividade estamos excluindo o atendimento");
});

module.exports = router;
