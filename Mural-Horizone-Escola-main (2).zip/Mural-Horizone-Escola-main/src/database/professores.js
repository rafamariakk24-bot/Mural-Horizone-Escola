const { db, ready } = require('./conexao');

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (error, row) => {
      if (error) {
        reject(error);
        return;
      }

      resolve(row);
    });
  });
}

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(error) {
      if (error) {
        reject(error);
        return;
      }

      resolve({ changes: this.changes });
    });
  });
}

async function getSubject(email) {
  await ready;
  const profile = await get('SELECT subject FROM perfis_professores WHERE email = ?', [email]);
  return profile?.subject || '';
}

async function saveSubject(email, subject) {
  await ready;
  await run(
    `INSERT INTO perfis_professores (email, subject)
     VALUES (?, ?)
     ON CONFLICT(email) DO UPDATE SET subject = excluded.subject`,
    [email, subject]
  );
  await run(
    `UPDATE avisos
     SET teacher_email = ?, teacher_subject = ?
     WHERE teacher_email = ?
        OR (teacher_email = '' AND author LIKE ?)`,
    [email, subject, email, `%: ${email}`]
  );
  return { email, subject };
}

async function getCourses(email) {
  await ready;
  const profile = await get('SELECT courses FROM perfis_professores WHERE email = ?', [email]);
  return profile?.courses ? JSON.parse(profile.courses) : [];
}

async function saveCourses(email, courses) {
  await ready;
  await run(
    `INSERT INTO perfis_professores (email, subject, courses)
     VALUES (?, '', ?)
     ON CONFLICT(email) DO UPDATE SET courses = excluded.courses`,
    [email, JSON.stringify(courses)]
  );
  return { email, courses };
}

async function getSeries(email) {
  await ready;
  const profile = await get('SELECT series FROM perfis_professores WHERE email = ?', [email]);
  return profile?.series ? JSON.parse(profile.series) : [];
}

async function saveSeries(email, series) {
  await ready;
  await run(
    `INSERT INTO perfis_professores (email, subject, series)
     VALUES (?, '', ?)
     ON CONFLICT(email) DO UPDATE SET series = excluded.series`,
    [email, JSON.stringify(series)]
  );
  return { email, series };
}

module.exports = { getSubject, saveSubject, getCourses, saveCourses, getSeries, saveSeries };
