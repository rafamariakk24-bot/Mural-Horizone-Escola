const { db, ready } = require('./conexao');

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(error) {
      if (error) {
        reject(error);
        return;
      }

      resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (error, rows) => {
      if (error) {
        reject(error);
        return;
      }

      resolve(rows);
    });
  });
}

async function list() {
  await ready;
  return all(
    `SELECT id, title, event_date AS date, event_time AS time, location
     FROM eventos
     ORDER BY event_date ASC, event_time ASC, id ASC`
  );
}

async function create(event) {
  await ready;
  const result = await run(
    `INSERT INTO eventos (title, event_date, event_time, location)
     VALUES (?, ?, ?, ?)`,
    [event.title.trim(), event.date, event.time || '', event.location?.trim() || '']
  );
  const [createdEvent] = await all(
    `SELECT id, title, event_date AS date, event_time AS time, location
     FROM eventos
     WHERE id = ?`,
    [result.id]
  );
  return createdEvent;
}

async function remove(id) {
  await ready;
  const result = await run('DELETE FROM eventos WHERE id = ?', [id]);
  return result.changes > 0;
}

module.exports = { list, create, remove };
