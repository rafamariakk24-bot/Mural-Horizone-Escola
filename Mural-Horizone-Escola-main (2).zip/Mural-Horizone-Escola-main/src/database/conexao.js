const path = require('node:path');
const fs = require('node:fs');
const sqlite3 = require('sqlite3').verbose();

const legacyDatabasePath = path.join(
  __dirname,
  '..',
  '..',
  'Mural-Horizone-Escola-main',
  'infraestrutura',
  'mural.db'
);
const legacyJournalPath = `${legacyDatabasePath}-journal`;
const databasePath = process.env.MURAL_DATABASE_PATH
  ? path.resolve(process.env.MURAL_DATABASE_PATH)
  : path.join(__dirname, '..', '..', 'data', 'mural.db');

fs.mkdirSync(path.dirname(databasePath), { recursive: true });
if (
  !process.env.MURAL_DATABASE_PATH &&
  !fs.existsSync(databasePath) &&
  fs.existsSync(legacyDatabasePath)
) {
  fs.copyFileSync(legacyDatabasePath, databasePath);
  if (fs.existsSync(legacyJournalPath)) {
    fs.copyFileSync(legacyJournalPath, `${databasePath}-journal`);
  }
}
let resolveReady;
let rejectReady;

const ready = new Promise((resolve, reject) => {
  resolveReady = resolve;
  rejectReady = reject;
});

const db = new sqlite3.Database(databasePath, error => {
  if (error) {
    rejectReady(error);
    return;
  }

  db.run(
    `CREATE TABLE IF NOT EXISTS avisos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      author TEXT NOT NULL,
      category TEXT NOT NULL,
      target_series TEXT NOT NULL DEFAULT '[]',
      target_audience TEXT NOT NULL DEFAULT '[]',
      subject TEXT NOT NULL DEFAULT '',
      date TEXT NOT NULL,
      due_date TEXT NOT NULL DEFAULT '',
      pinned INTEGER NOT NULL DEFAULT 0,
      attachment TEXT
    )`,
    schemaError => {
      if (schemaError) {
        rejectReady(schemaError);
        return;
      }

      db.run(
        `CREATE TABLE IF NOT EXISTS eventos (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          event_date TEXT NOT NULL,
          event_time TEXT NOT NULL DEFAULT '',
          location TEXT NOT NULL DEFAULT ''
        )`,
        eventsSchemaError => {
          if (eventsSchemaError) {
            rejectReady(eventsSchemaError);
            return;
          }

          db.run(
            `CREATE TABLE IF NOT EXISTS perfis_professores (
              email TEXT PRIMARY KEY,
              subject TEXT NOT NULL,
              courses TEXT NOT NULL DEFAULT '[]',
              series TEXT NOT NULL DEFAULT '[]'
            )`,
            profileSchemaError => {
              if (profileSchemaError) {
                rejectReady(profileSchemaError);
                return;
              }

              db.all('PRAGMA table_info(perfis_professores)', (profileColumnsError, profileColumns) => {
                if (profileColumnsError) {
                  rejectReady(profileColumnsError);
                  return;
                }

                const addProfileColumn = (name, definition) => (
                  profileColumns.some(column => column.name === name)
                    ? Promise.resolve()
                    : new Promise((resolve, reject) => {
                      db.run(`ALTER TABLE perfis_professores ADD COLUMN ${definition}`, error => {
                        if (error) reject(error);
                        else resolve();
                      });
                    })
                );

                Promise.all([
                  addProfileColumn('courses', "courses TEXT NOT NULL DEFAULT '[]'"),
                  addProfileColumn('series', "series TEXT NOT NULL DEFAULT '[]'")
                ])
                  .then(() => new Promise((resolve, reject) => {
                    db.all('PRAGMA table_info(avisos)', (columnsError, columns) => {
                      if (columnsError) {
                        reject(columnsError);
                        return;
                      }

                      const addColumn = (name, definition) => new Promise((resolveColumn, rejectColumn) => {
                        if (columns.some(column => column.name === name)) {
                          resolveColumn();
                          return;
                        }

                        db.run(`ALTER TABLE avisos ADD COLUMN ${definition}`, error => {
                          if (error) rejectColumn(error);
                          else resolveColumn();
                        });
                      });

                      Promise.all([
                        addColumn('teacher_email', 'teacher_email TEXT NOT NULL DEFAULT \'\''),
                        addColumn('teacher_subject', 'teacher_subject TEXT NOT NULL DEFAULT \'\''),
                        addColumn('target_series', 'target_series TEXT NOT NULL DEFAULT \'[]\''),
                        addColumn('target_audience', 'target_audience TEXT NOT NULL DEFAULT \'[]\'')
                      ])
                        .then(resolve)
                        .catch(reject);
                    });
                  }))
                  .then(() => resolveReady(db))
                  .catch(rejectReady);
              });
            }
          );
          }
      );
    }
  );
});

function close() {
  return new Promise((resolve, reject) => {
    db.close(error => {
      if (error) {
        reject(error);
        return;
      }

      resolve();
    });
  });
}

module.exports = { db, ready, databasePath, close };