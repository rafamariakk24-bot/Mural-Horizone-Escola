const { db, ready, close } = require('./conexao');

const initialNotices = [
  {
    title: 'Bem-vindos ao novo ano letivo!',
    content: 'Que este seja um ano cheio de descobertas, encontros e muito aprendizado. Estamos felizes em ter vocês de volta.',
    author: 'Direção da escola',
    category: 'Importante',
    date: 'Hoje, 08:15',
    pinned: true
  },
  {
    title: 'Inscrições abertas para a feira de ciências',
    content: 'As equipes podem se inscrever até sexta-feira na secretaria. Consulte o regulamento no mural da sua sala.',
    author: 'Professor(a) Marcelo',
    category: 'Eventos',
    date: 'Ontem, 16:40'
  },
  {
    title: 'Material para a aula de História',
    content: 'Não esqueçam de trazer o caderno de atividades e o texto sobre a formação do Brasil na próxima aula.',
    author: 'Professor(a) responsável',
    category: 'Acadêmico',
    date: '22 de ago., 11:20'
  },
  {
    title: 'Atividade de Matemática para entregar',
    content: 'Resolver os exercícios 1 a 10 da página 42 e entregar na próxima aula.',
    author: 'Professor(a) responsável',
    category: 'Atividade para entregar',
    date: '21 de ago., 10:00',
    dueDate: '2026-08-29'
  },
  {
    title: 'Trabalho de Literatura',
    content: 'Produzir uma análise de uma obra literária e enviar o arquivo em PDF.',
    author: 'Professor(a) responsável',
    category: 'Trabalho',
    date: '20 de ago., 09:30',
    dueDate: '2026-09-05'
  }
];

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(error) {
      if (error) {
        reject(error);
        return;
      }

      resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (error, row) => {
      if (error) {
        reject(error);
        return;
      }

      resolve(row);
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (error, rows) => {
      if (error) {
        reject(error);
        return;
      }

      resolve(rows);
    });
  });
}

function mapNotice(row) {
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    author: row.author,
    teacherEmail: row.teacher_email || '',
    teacherSubject: row.teacher_subject || '',
    series: JSON.parse(row.target_series || '[]'),
    audience: JSON.parse(row.target_audience || '[]'),
    category: row.category,
    subject: row.subject,
    date: row.date,
    dueDate: row.due_date || '',
    pinned: Boolean(row.pinned),
    attachment: row.attachment ? JSON.parse(row.attachment) : null
  };
}

async function findById(id) {
  await ready;
  const row = await get('SELECT * FROM avisos WHERE id = ?', [id]);
  return row ? mapNotice(row) : null;
}

async function insert(notice) {
  const result = await run(
    `INSERT INTO avisos
      (title, content, author, teacher_email, teacher_subject, target_series, target_audience, category, subject, date, due_date, pinned, attachment)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      notice.title.trim(),
      notice.content.trim(),
      notice.author.trim(),
      notice.teacherEmail || '',
      notice.teacherSubject?.trim() || '',
      JSON.stringify(notice.series || []),
      JSON.stringify(notice.audience || []),
      notice.category.trim(),
      notice.subject?.trim() || '',
      notice.date || 'Agora',
      notice.dueDate || '',
      notice.pinned ? 1 : 0,
      notice.attachment ? JSON.stringify(notice.attachment) : null
    ]
  );

  return findById(result.id);
}

async function initialize() {
  await ready;
  const row = await get('SELECT COUNT(*) AS count FROM avisos');
  if (row.count > 0) return;

  for (const notice of initialNotices) {
    await insert(notice);
  }
}

async function list(serie, turma) {
  await ready;
  const rows = await all('SELECT * FROM avisos ORDER BY id DESC');
  const notices = rows.map(mapNotice);
  if (!serie || !turma) return notices;

  return notices.filter(notice => {
    if (notice.audience.length) {
      return notice.audience.some(target => target.serie === serie && target.turma === turma);
    }
    return notice.series.length === 0 || notice.series.includes(serie);
  });
}

async function checkDatabase() {
  await ready;
  await get('SELECT 1 AS connected');
}

async function create(notice) {
  await ready;
  return insert({ ...notice, date: 'Agora' });
}

async function update(id, notice) {
  await ready;
  const result = await run(
    `UPDATE avisos
     SET title = ?, content = ?, author = ?, teacher_email = ?, teacher_subject = ?, target_series = ?,
         target_audience = ?, category = ?, subject = ?,
         date = ?, due_date = ?, pinned = ?, attachment = ?
     WHERE id = ?`,
    [
      notice.title.trim(),
      notice.content.trim(),
      notice.author.trim(),
      notice.teacherEmail || '',
      notice.teacherSubject?.trim() || '',
      JSON.stringify(notice.series || []),
      JSON.stringify(notice.audience || []),
      notice.category.trim(),
      notice.subject?.trim() || '',
      'Editado agora',
      notice.dueDate || '',
      notice.pinned ? 1 : 0,
      notice.attachment ? JSON.stringify(notice.attachment) : null,
      id
    ]
  );

  return result.changes ? findById(id) : null;
}

async function remove(id) {
  await ready;
  const result = await run('DELETE FROM avisos WHERE id = ?', [id]);
  return result.changes > 0;
}

module.exports = { initialize, list, create, update, remove, checkDatabase, close };