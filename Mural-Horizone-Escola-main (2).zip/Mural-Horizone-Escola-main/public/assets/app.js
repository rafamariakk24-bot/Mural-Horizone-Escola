const credentials = {
  aluno: { emailDomain: 'aluno.edu.pi.gov.br', password: '1234', label: 'Aluno' },
  professor: { emailDomain: 'professor.edu.pi.gov.br', password: '5678', label: 'Professor(a)' }
};
const noticeCourses = ['Desenvolvimento de Sistemas', 'Alimentos', 'Farmácia'];

function hasInstitutionalDomain(email, domain) {
  const parts = email.split('@');
  return parts.length === 2 && parts[0].length > 0 && parts[1].toLowerCase() === domain;
}

const loginScreen = document.querySelector('#login-screen');
const loginForm = document.querySelector('#login-form');
const loginError = document.querySelector('#login-error');
const appShell = document.querySelector('.app-shell');
const noticeList = document.querySelector('#notice-list');
const emptyState = document.querySelector('#empty-state');
const calendarList = document.querySelector('#calendar-list');
const calendarEmpty = document.querySelector('#calendar-empty');
const eventModal = document.querySelector('#event-modal');
const eventForm = document.querySelector('#event-form');
const openEventModalButton = document.querySelector('#open-event-modal');
const modal = document.querySelector('#notice-modal');
const form = document.querySelector('#notice-form');
const categorySelect = document.querySelector('#notice-category');
const subjectField = document.querySelector('#subject-field');
const subjectInput = document.querySelector('#notice-subject');
const subjectLabel = document.querySelector('#notice-subject-label');
const subjectHelp = document.querySelector('#notice-subject-help');
const profileDialog = document.querySelector('#profile-dialog');
const classField = document.querySelector('#class-field');
const loginTeacherTypeField = document.querySelector('#login-teacher-type-field');
const loginTeacherTypeSelect = document.querySelector('#login-teacher-type');
const loginTeacherSubjectField = document.querySelector('#login-teacher-subject-field');
const loginTeacherSubjectInput = document.querySelector('#login-teacher-subject');
const loginTeacherCoursesField = document.querySelector('#login-teacher-courses-field');
const loginTeacherSeriesField = document.querySelector('#login-teacher-series-field');
const loginTeacherCoursesInputs = document.querySelectorAll('[name="teacherCourses"]');
const loginTeacherSeriesInputs = document.querySelectorAll('[name="teacherSeries"]');
const teacherCourseStatus = document.querySelector('#teacher-course-status');
const seriesSelect = document.querySelector('#login-series');
const classSelect = document.querySelector('#login-class');
const emailInput = document.querySelector('#login-email');
const assessmentCategories = ['Prova', 'ENEM', 'Vestibular', 'Simulado'];
const sessionParams = new URLSearchParams(window.location.search);
const sessionRole = sessionParams.get('role');
const sessionAccount = credentials[sessionRole];
const sessionEmail = sessionParams.get('email')?.trim().toLowerCase() || '';
const session = sessionAccount && hasInstitutionalDomain(sessionEmail, sessionAccount.emailDomain)
  ? {
      role: sessionRole,
      email: sessionEmail,
      label: sessionAccount.label,
      serie: sessionParams.get('serie') || '',
      turma: sessionParams.get('turma') || ''
    }
  : null;

let notices = [];
let calendarEvents = [];
let currentFilter = 'Todos';
let editingNoticeId = null;
let currentRole = session?.role || 'aluno';
let currentUser = session;
let teacherCoursesLoaded = currentRole !== 'professor';

async function requestApi(url, options = {}) {
  let response;
  try {
    response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
  } catch {
    throw new Error('Não foi possível conectar ao servidor. Inicie o projeto com "npm start" e abra http://localhost:3120/mural/.');
  }

  if (response.status === 204) return null;

  const responseText = await response.text();
  let result;
  try {
    result = JSON.parse(responseText);
  } catch {
    const message = response.status === 405
      ? 'Este endereço não está atendendo à API do mural (HTTP 405). Execute "npm start" na pasta do projeto e abra http://localhost:3120/mural/. Não abra pelo Live Server.'
      : response.ok
        ? 'O servidor respondeu em um formato inválido. Reinicie o projeto e tente novamente.'
        : `O servidor respondeu com erro (HTTP ${response.status}). Reinicie o projeto e tente novamente.`;
    throw new Error(message);
  }

  if (!response.ok) {
    throw new Error(result.error || 'Não foi possível concluir a operação.');
  }

  return result;
}

function setAuthenticatedUser(user) {
  currentUser = user;
  document.body.classList.add('authenticated');

  if (loginScreen) {
    loginScreen.hidden = true;
  }

  if (appShell) {
    appShell.hidden = false;
  }

  const userButton = document.querySelector('#logged-user');
  if (userButton) {
    userButton.textContent = `${user.label}: ${user.email}`;
  }

  updateProfile(user);
}

function updateProfile(user) {
  const profileName = document.querySelector('#profile-name');
  const profileUsername = document.querySelector('#profile-username');
  const profileRole = document.querySelector('#profile-role');
  const profileSeries = document.querySelector('#profile-series');
  const profileClass = document.querySelector('#profile-class');
  const profileSeriesRow = document.querySelector('#profile-series-row');
  const profileClassRow = document.querySelector('#profile-class-row');
  const profileAvatar = document.querySelector('#profile-avatar');
  const profilePermissions = document.querySelector('#profile-permissions');
  const profileTeacherDetails = document.querySelector('#profile-teacher-details');
  const profileTeacherType = document.querySelector('#profile-teacher-type');
  const profileSubjectRow = document.querySelector('#profile-subject-row');
  const profileSubject = document.querySelector('#profile-subject');
  const profileCourses = document.querySelector('#profile-courses');
  const profileTeacherSeries = document.querySelector('#profile-teacher-series');

  if (!profileName || !profileUsername || !profileRole || !profileSeries || !profileClass || !profileAvatar || !profilePermissions) return;

  profileName.textContent = user.label;
  profileUsername.textContent = user.email;
  profileRole.textContent = user.role === 'professor' ? 'Professor(a)' : 'Aluno';
  if (profileSeriesRow) profileSeriesRow.hidden = user.role !== 'aluno';
  if (profileClassRow) profileClassRow.hidden = user.role !== 'aluno';
  profileSeries.textContent = user.role === 'aluno' ? (user.serie || 'Não informada') : 'Não se aplica';
  profileClass.textContent = user.role === 'aluno' ? (user.turma || 'Não informada') : 'Não se aplica';
  profileAvatar.textContent = user.role === 'professor' ? 'P' : 'A';
  profilePermissions.textContent = user.role === 'professor'
    ? 'Você pode publicar, editar e excluir avisos e atividades.'
    : 'Você pode visualizar avisos, provas, atividades e anexos.';

  if (profileTeacherDetails) profileTeacherDetails.hidden = user.role !== 'professor';
  if (user.role === 'professor') {
    const profileLoaded = Boolean(user.teacherProfileLoaded);
    const isDisciplineTeacher = profileLoaded && Boolean(user.subject);
    const courses = user.courses || [];
    if (profileTeacherType) {
      profileTeacherType.textContent = !profileLoaded
        ? 'Carregando...'
        : isDisciplineTeacher
          ? 'Professor(a) de disciplina'
          : courses.length === 1
            ? `Professor(a) de ${courses[0]}`
            : courses.length > 1
              ? `Professor(a) dos cursos: ${courses.join(', ')}`
              : 'Professor(a) do curso';
    }
    if (profileSubjectRow) profileSubjectRow.hidden = !isDisciplineTeacher;
    if (profileSubject) profileSubject.textContent = user.subject || '';
    if (profileCourses) {
      profileCourses.textContent = !profileLoaded
        ? 'Carregando...'
        : courses.length ? courses.join(', ') : 'Nenhum curso vinculado.';
    }
    if (profileTeacherSeries) {
      profileTeacherSeries.textContent = !profileLoaded
        ? 'Carregando...'
        : user.series?.length ? user.series.join(', ') : 'Nenhuma série vinculada.';
    }
  }
}

function escapeHtml(value) {
  const element = document.createElement('div');
  element.textContent = value;
  return element.innerHTML;
}

function neutralizeProfessorLabel(value) {
  return value
    .replace(/\bprofessoras\b/gi, 'professor(a)s')
    .replace(/\bprofessores\b/gi, 'professor(a)s')
    .replace(/\bprofessora\b(?!\s*\(a\))/gi, 'professor(a)')
    .replace(/\bprofessor\b(?!\s*\(a\))/gi, 'professor(a)')
    .replace(/\bprof\.\s*/gi, 'Professor(a) ');
}

function subjectMarkup(notice) {
  if (!notice.subject || !assessmentCategories.includes(notice.category)) return '';
  return `<div class="notice-subject"><span>Assunto da avaliação</span><strong>${escapeHtml(notice.subject)}</strong></div>`;
}

function noticeAudienceMarkup(notice) {
  if (currentRole !== 'professor') return '';
  const audience = notice.audience?.length
    ? notice.audience.map(target => `${target.serie} — ${target.turma}`).join(', ')
    : notice.series?.length ? `${notice.series.join(', ')} · todos os cursos` : 'Todas as séries e cursos';
  return `<div class="teacher-subject-label"><span>Público</span><strong>${escapeHtml(audience)}</strong></div>`;
}

function updateAudienceCourses(courses, series) {
  document.querySelectorAll('[name="audience"]').forEach(input => {
    const [serie, course] = input.value.split('::');
    const allowed = courses.includes(course) && series.includes(serie);
    const choice = input.closest('.audience-choice');
    if (choice) choice.hidden = !allowed;
    if (!allowed) input.checked = false;
    if (!allowed) input.checked = false;
  });
  document.querySelectorAll('.audience-grade-group').forEach(group => {
    group.hidden = !Array.from(group.querySelectorAll('[name="audience"]'))
      .some(input => {
        const [serie, course] = input.value.split('::');
        return courses.includes(course) && series.includes(serie);
      });
  });
}

function attachmentMarkup(attachment) {
  if (!attachment) return '';

  const safeData = escapeHtml(attachment.data);
  const safeName = escapeHtml(attachment.name);

  if (attachment.type.startsWith('image/')) {
    return `<a class="attachment-image-link" href="${safeData}" target="_blank" rel="noopener"><img class="attachment-image" src="${safeData}" alt="${safeName}"></a><span class="attachment-name">${safeName}</span>`;
  }

  return `<a class="attachment-file" href="${safeData}" target="_blank" rel="noopener">▣ <span>${safeName}</span><b>Abrir PDF</b></a>`;
}

function deadlineMarkup(notice) {
  if (!notice.dueDate) return '';

  const expired = new Date(`${notice.dueDate}T23:59:59`) < new Date();
  const formattedDate = new Date(`${notice.dueDate}T12:00:00`).toLocaleDateString('pt-BR');

  if (!expired) {
    return `<div class="deadline active"><span>▣ Prazo de entrega</span><strong>${formattedDate}</strong></div>`;
  }

  const guidance = currentRole === 'professor'
    ? 'Edite este aviso para colocar um novo prazo.'
    : 'Fale com o(a) professor(a) para colocar um novo prazo.';

  return `<div class="deadline expired"><span>! Prazo encerrado em ${formattedDate}</span><strong>${guidance}</strong></div>`;
}

function renderNotices() {
  if (!noticeList || !emptyState) return;

  const visibleNotices = notices
    .filter(notice => currentFilter === 'Todos' || notice.category === currentFilter)
    .sort((a, b) => Number(b.pinned) - Number(a.pinned));

  noticeList.innerHTML = visibleNotices.map((notice, index) => `
    <article class="notice-card ${notice.pinned ? 'pinned' : ''}" style="animation-delay:${index * 60}ms">
      <div class="notice-meta"><span class="category">${notice.pinned ? '★ fixado' : notice.category}</span><span>${notice.date}</span></div>
      <h3>${escapeHtml(notice.title)}</h3>
      <p>${escapeHtml(notice.content)}</p>
      ${subjectMarkup(notice)}
      ${noticeAudienceMarkup(notice)}
      ${deadlineMarkup(notice)}
      ${attachmentMarkup(notice.attachment)}
      ${notice.teacherSubject ? `<div class="teacher-subject-label"><span>Matéria</span><strong>${escapeHtml(notice.teacherSubject)}</strong></div>` : ''}
      <div class="notice-meta" style="margin-top:18px">
        <span>Por ${escapeHtml(neutralizeProfessorLabel(notice.author))}</span>
        ${currentRole === 'professor' ? `<span class="card-actions"><button class="edit-button" type="button" data-edit="${notice.id}" aria-label="Editar aviso" title="Editar aviso">✎</button><button class="delete-button" type="button" data-delete="${notice.id}" aria-label="Excluir aviso" title="Excluir aviso">×</button></span>` : ''}
      </div>
    </article>
  `).join('');

  emptyState.hidden = visibleNotices.length > 0;

  const allCount = document.querySelector('#all-count');
  const openModalButton = document.querySelector('#open-modal');
  const resultLabel = document.querySelector('#result-label');

  if (allCount) allCount.textContent = notices.length;
  if (openModalButton) {
    openModalButton.hidden = currentRole !== 'professor' ||
      !teacherCoursesLoaded ||
      !currentUser?.courses?.length ||
      !currentUser?.series?.length;
  }
  if (teacherCourseStatus) {
    teacherCourseStatus.hidden = currentRole !== 'professor' ||
      (teacherCoursesLoaded && currentUser?.courses?.length > 0 && currentUser?.series?.length > 0);
    teacherCourseStatus.textContent = teacherCoursesLoaded
      ? 'Vincule cursos e séries no login para poder publicar avisos.'
      : 'Carregando cursos e séries vinculados ao perfil...';
  }
  if (resultLabel) resultLabel.textContent = currentFilter === 'Todos' ? 'todos os avisos' : `categoria: ${currentFilter.toLowerCase()}`;
}

function renderCalendar() {
  if (!calendarList || !calendarEmpty) return;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const upcomingEvents = calendarEvents.filter(event => new Date(`${event.date}T00:00:00`) >= today);

  const eventMarkup = upcomingEvents.map((event, index) => {
    const eventDate = new Date(`${event.date}T12:00:00`);
    const day = eventDate.toLocaleDateString('pt-BR', { day: '2-digit' });
    const month = eventDate.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '').toUpperCase();
    const details = [event.location, event.time].filter(Boolean).map(escapeHtml).join(' · ');
    const colors = ['coral', 'blue', 'yellow'];

    return `
      <div class="calendar-item">
        <time datetime="${escapeHtml(event.date)}"><b>${day}</b><small>${month}</small></time>
        <div><strong>${escapeHtml(event.title)}</strong><p>${details || 'Evento escolar'}</p></div>
        <span class="dot ${colors[index % colors.length]}"></span>
        ${currentRole === 'professor' ? `<button class="calendar-delete-button" type="button" data-delete-event="${event.id}" aria-label="Excluir evento ${escapeHtml(event.title)}" title="Excluir evento">×</button>` : ''}
      </div>
    `;
  }).join('');

  calendarList.innerHTML = eventMarkup || '<p class="calendar-empty">Nenhum evento próximo cadastrado.</p>';
}

async function loadCalendarEvents() {
  if (!calendarList || !calendarEmpty) return;

  try {
    calendarEvents = await requestApi('/api/eventos');
    renderCalendar();
  } catch (error) {
    console.error('Não foi possível carregar os eventos:', error);
    calendarList.innerHTML = `<p class="calendar-empty">${escapeHtml(error.message || 'Não foi possível carregar os eventos.')}</p>`;
  }
}

function setCurrentFilter(filter) {
  currentFilter = filter;
  document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.classList.toggle('active', tab.dataset.filter === filter);
  });
}

async function loadNotices() {
  try {
    const params = new URLSearchParams();
    if (session?.role) params.set('role', session.role);
    if (session?.role === 'aluno') {
      params.set('serie', session.serie);
      params.set('turma', session.turma);
    }
    const query = params.toString();
    notices = await requestApi(`/api/avisos${query ? `?${query}` : ''}`);
    renderNotices();
  } catch (error) {
    console.error('Não foi possível carregar os avisos:', error);
    if (noticeList) noticeList.replaceChildren();
    if (emptyState) {
      emptyState.hidden = false;
      emptyState.innerHTML = '<span>!</span><h3>Não foi possível carregar os avisos</h3><p>Verifique se o servidor está ativo e recarregue a página.</p>';
    }
  }
}

function updateSubjectField() {
  if (!categorySelect || !subjectField || !subjectInput) return;

  const isAssessment = assessmentCategories.includes(categorySelect.value);
  subjectField.hidden = !isAssessment;
  subjectInput.required = isAssessment;

  if (subjectLabel) {
    subjectLabel.textContent = categorySelect.value === 'ENEM'
      ? 'Áreas e conteúdos do ENEM'
      : 'Conteúdos que serão cobrados';
  }
  if (subjectHelp) {
    subjectHelp.textContent = isAssessment
      ? 'Preencha este campo para publicar ou salvar a avaliação.'
      : 'Esse conteúdo aparecerá no aviso para os alunos.';
  }
}

function getCurrentAuthor() {
  return currentUser ? `${currentUser.label}: ${currentUser.email}` : 'Usuário não identificado';
}

function openNewNotice() {
  if (!form || !modal) return;

  editingNoticeId = null;
  form.reset();
  updateSubjectField();
  document.querySelector('#notice-author').value = getCurrentAuthor();
  document.querySelector('#modal-eyebrow').textContent = 'novo comunicado';
  document.querySelector('#modal-title').textContent = 'Publicar um aviso';
  document.querySelector('#submit-notice').firstChild.textContent = 'Publicar aviso ';
  modal.showModal();
  document.querySelector('#notice-title').focus();
}

function updateClassField() {
  const role = document.querySelector('#login-role')?.value;
  const isStudent = role === 'aluno';
  const isTeacher = role === 'professor';
  if (classField && seriesSelect && classSelect) {
    classField.hidden = !isStudent;
    seriesSelect.required = isStudent;
    classSelect.required = isStudent;
  }
  if (loginTeacherTypeField && loginTeacherTypeSelect) {
    loginTeacherTypeField.hidden = !isTeacher;
    loginTeacherTypeSelect.required = isTeacher;
  }
  if (loginTeacherSubjectField && loginTeacherSubjectInput) {
    const isDisciplineTeacher = isTeacher && loginTeacherTypeSelect?.value === 'disciplina';
    loginTeacherSubjectField.hidden = !isDisciplineTeacher;
    loginTeacherSubjectInput.required = isDisciplineTeacher;
  }
  if (loginTeacherCoursesField) loginTeacherCoursesField.hidden = !isTeacher;
  if (loginTeacherSeriesField) loginTeacherSeriesField.hidden = !isTeacher;
  if (emailInput) {
    emailInput.placeholder = isStudent
      ? 'nome@aluno.edu.pi.gov.br'
      : 'nome@professor.edu.pi.gov.br';
  }
}

function attachEventHandlers() {
  if (session && credentials[session.role] && hasInstitutionalDomain(session.email, credentials[session.role].emailDomain)) {
    setAuthenticatedUser(session);
  }

  if (loginForm) {
    updateClassField();
    const loginRoleSelect = document.querySelector('#login-role');
    const loadTeacherProfileForLogin = async () => {
      if (
        loginRoleSelect?.value !== 'professor' ||
        !loginTeacherSubjectInput ||
        !hasInstitutionalDomain(emailInput.value.trim().toLowerCase(), credentials.professor.emailDomain)
      ) return;

      const email = emailInput.value.trim().toLowerCase();
      try {
        const encodedEmail = encodeURIComponent(email);
        const [profile, courseProfile, seriesProfile] = await Promise.all([
          requestApi(`/api/professores/${encodedEmail}/materia`),
          requestApi(`/api/professores/${encodedEmail}/cursos`),
          requestApi(`/api/professores/${encodedEmail}/series`)
        ]);
        if (emailInput.value.trim().toLowerCase() === email) {
          loginTeacherSubjectInput.value = profile.subject || '';
          loginTeacherTypeSelect.value = profile.subject ? 'disciplina' : 'curso';
          updateClassField();
          loginTeacherCoursesInputs.forEach(input => {
            input.checked = courseProfile.courses.includes(input.value);
          });
          loginTeacherSeriesInputs.forEach(input => {
            input.checked = seriesProfile.series.includes(input.value);
          });
        }
      } catch (error) {
        console.error('Não foi possível carregar o perfil do(a) professor(a):', error);
        loginError.textContent = error.message;
      }
    };

    loginRoleSelect?.addEventListener('change', () => {
      updateClassField();
      loadTeacherProfileForLogin();
    });
    loginTeacherTypeSelect?.addEventListener('change', updateClassField);
    emailInput?.addEventListener('blur', loadTeacherProfileForLogin);

    loginForm.addEventListener('submit', async event => {
      event.preventDefault();

      const role = document.querySelector('#login-role').value;
      const serie = role === 'aluno' ? document.querySelector('#login-series').value : '';
      const turma = role === 'aluno' ? document.querySelector('#login-class').value : '';
      const email = document.querySelector('#login-email').value.trim().toLowerCase();
      const password = document.querySelector('#login-password').value;
      const account = credentials[role];

      if (!hasInstitutionalDomain(email, account.emailDomain) || password !== account.password) {
        loginError.textContent = `Informe seu e-mail institucional (@${account.emailDomain}) e a senha correta para este perfil.`;
        return;
      }

      if (role === 'professor') {
        const teacherType = loginTeacherTypeSelect.value;
        const subject = teacherType === 'disciplina' ? loginTeacherSubjectInput.value.trim() : '';
        const courses = Array.from(loginTeacherCoursesInputs)
          .filter(input => input.checked)
          .map(input => input.value);
        const series = Array.from(loginTeacherSeriesInputs)
          .filter(input => input.checked)
          .map(input => input.value);
        if (!teacherType) {
          loginError.textContent = 'Escolha se você é professor(a) de uma disciplina ou do curso.';
          loginTeacherTypeSelect.focus();
          return;
        }
        if (teacherType === 'disciplina' && !subject) {
          loginError.textContent = 'Informe a disciplina que você leciona.';
          loginTeacherSubjectInput.focus();
          return;
        }
        if (!courses.length) {
          loginError.textContent = 'Selecione pelo menos um curso em que você leciona.';
          loginTeacherCoursesInputs[0]?.focus();
          return;
        }
        if (!series.length) {
          loginError.textContent = 'Selecione pelo menos uma série em que você leciona.';
          loginTeacherSeriesInputs[0]?.focus();
          return;
        }

        try {
          const encodedEmail = encodeURIComponent(email);
          await Promise.all([
            requestApi(`/api/professores/${encodedEmail}/materia`, {
              method: 'PUT',
              body: JSON.stringify({ subject })
            }),
            requestApi(`/api/professores/${encodedEmail}/cursos`, {
              method: 'PUT',
              body: JSON.stringify({ courses })
            }),
            requestApi(`/api/professores/${encodedEmail}/series`, {
              method: 'PUT',
              body: JSON.stringify({ series })
            })
          ]);
        } catch (error) {
          console.error('Não foi possível salvar o perfil do(a) professor(a):', error);
          loginError.textContent = error.message;
          return;
        }
      }

      loginError.textContent = '';
      const destination = new URL('mural.html', window.location.href);
      destination.searchParams.set('role', role);
      destination.searchParams.set('email', email);
      if (serie) destination.searchParams.set('serie', serie);
      if (turma) destination.searchParams.set('turma', turma);
      window.location.href = destination.toString();
    });
  }

  if (currentUser?.role === 'professor') {
    const encodedEmail = encodeURIComponent(currentUser.email);
    Promise.all([
      requestApi(`/api/professores/${encodedEmail}/materia`),
      requestApi(`/api/professores/${encodedEmail}/cursos`),
      requestApi(`/api/professores/${encodedEmail}/series`)
    ])
      .then(([profile, courseProfile, seriesProfile]) => {
        currentUser.subject = profile.subject;
        currentUser.courses = courseProfile.courses;
        currentUser.series = seriesProfile.series;
        currentUser.teacherProfileLoaded = true;
        teacherCoursesLoaded = true;
        updateProfile(currentUser);
        updateAudienceCourses(currentUser.courses, currentUser.series);
        notices = notices.map(notice => (
          notice.teacherEmail === currentUser.email ||
          (!notice.teacherEmail && notice.author.endsWith(`: ${currentUser.email}`))
        ) ? {
          ...notice,
          teacherEmail: currentUser.email,
          teacherSubject: profile.subject
        } : notice);
        renderNotices();
      })
      .catch(error => {
        console.error('Não foi possível carregar o perfil do(a) professor(a):', error);
        teacherCoursesLoaded = false;
        currentUser.teacherProfileLoaded = true;
        const profileTeacherType = document.querySelector('#profile-teacher-type');
        if (profileTeacherType) profileTeacherType.textContent = 'Não foi possível carregar os dados.';
        const profileCourses = document.querySelector('#profile-courses');
        if (profileCourses) profileCourses.textContent = 'Não foi possível carregar os cursos.';
        const profileTeacherSeries = document.querySelector('#profile-teacher-series');
        if (profileTeacherSeries) profileTeacherSeries.textContent = 'Não foi possível carregar as séries.';
        if (teacherCourseStatus) {
          teacherCourseStatus.hidden = false;
          teacherCourseStatus.textContent = error.message;
        }
        renderNotices();
      });
  }

  const logoutButton = document.querySelector('#logout-button');
  if (logoutButton) {
    logoutButton.addEventListener('click', () => {
      window.location.href = 'rafa.html';
    });
  }

  const filterTabs = document.querySelectorAll('.filter-tab');
  filterTabs.forEach(button => {
    button.addEventListener('click', () => {
      setCurrentFilter(button.dataset.filter);
      renderNotices();
    });
  });

  if (categorySelect) {
    categorySelect.addEventListener('change', updateSubjectField);
  }

  if (openEventModalButton && eventModal && eventForm) {
    openEventModalButton.hidden = currentRole !== 'professor';
    openEventModalButton.addEventListener('click', () => {
      eventForm.reset();
      const eventDateInput = document.querySelector('#event-date');
      const today = new Date();
      eventDateInput.min = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      eventModal.showModal();
      document.querySelector('#event-title').focus();
    });

    document.querySelector('#close-event-modal')?.addEventListener('click', () => eventModal.close());
    eventModal.addEventListener('click', event => {
      if (event.target === eventModal) eventModal.close();
    });

    eventForm.addEventListener('submit', async event => {
      event.preventDefault();
      const data = new FormData(eventForm);

      try {
        const createdEvent = await requestApi('/api/eventos', {
          method: 'POST',
          body: JSON.stringify({
            title: data.get('title'),
            date: data.get('date'),
            time: data.get('time'),
            location: data.get('location')
          })
        });
        calendarEvents.push(createdEvent);
        renderCalendar();
        eventForm.reset();
        eventModal.close();
      } catch (error) {
        console.error('Não foi possível salvar o evento:', error);
        window.alert(error.message);
      }
    });
  }

  if (calendarList) {
    calendarList.addEventListener('click', async event => {
      if (currentRole !== 'professor') return;

      const button = event.target.closest('[data-delete-event]');
      if (!button || !window.confirm('Excluir este evento do calendário?')) return;

      try {
        await requestApi(`/api/eventos/${button.dataset.deleteEvent}`, { method: 'DELETE' });
        calendarEvents = calendarEvents.filter(item => String(item.id) !== button.dataset.deleteEvent);
        renderCalendar();
      } catch (error) {
        console.error('Não foi possível excluir o evento:', error);
        window.alert(error.message);
      }
    });
  }

  const openModalButton = document.querySelector('#open-modal');
  if (openModalButton) {
    openModalButton.addEventListener('click', () => {
      openNewNotice();
    });
  }

  if (modal) {
    document.querySelector('#close-modal')?.addEventListener('click', () => modal.close());
    modal.addEventListener('click', event => {
      if (event.target === modal) modal.close();
    });
  }

  if (!form) {
    return;
  }

  form.addEventListener('submit', event => {
    event.preventDefault();

    const data = new FormData(form);
    const selectedFile = data.get('attachment');
    const existingNotice = editingNoticeId
      ? notices.find(item => item.id === editingNoticeId)
      : null;

    if (selectedFile && selectedFile.size > 2 * 1024 * 1024) {
      window.alert('O arquivo deve ter no máximo 2 MB.');
      return;
    }

    const finishSave = async attachment => {
      const selectedAudience = data.getAll('audience').map(value => {
        const [serie, turma] = value.split('::');
        return { serie, turma };
      });
      if (!selectedAudience.length) {
        window.alert('Selecione pelo menos uma combinação de série e curso para receber o aviso.');
        document.querySelector('[name="audience"]')?.focus();
        return;
      }

      const noticeData = {
        title: data.get('title'),
        content: data.get('content'),
        author: editingNoticeId ? data.get('author') : getCurrentAuthor(),
        teacherEmail: currentUser?.role === 'professor' ? currentUser.email : '',
        teacherSubject: currentUser?.role === 'professor' ? currentUser.subject || '' : '',
        category: data.get('category'),
        audience: selectedAudience,
        subject: data.get('subject')?.trim() || '',
        dueDate: data.get('dueDate') || '',
        pinned: data.has('pinned')
      };

      if (attachment) noticeData.attachment = attachment;

      try {
        if (editingNoticeId) {
          const updatedNotice = await requestApi(`/api/avisos/${editingNoticeId}`, {
            method: 'PUT',
            body: JSON.stringify(noticeData)
          });
          notices = notices.map(notice => notice.id === editingNoticeId ? updatedNotice : notice);
        } else {
          const createdNotice = await requestApi('/api/avisos', {
            method: 'POST',
            body: JSON.stringify(noticeData)
          });
          notices.unshift(createdNotice);
        }
      } catch (error) {
        console.error('Não foi possível salvar o aviso:', error);
        window.alert(error.message);
        return;
      }

      setCurrentFilter('Todos');
      renderNotices();
      form.reset();
      document.querySelector('#notice-author').value = getCurrentAuthor();
      editingNoticeId = null;
      modal.close();
    };

    if (selectedFile && selectedFile.size) {
      const reader = new FileReader();
      reader.onload = () => finishSave({
        name: selectedFile.name,
        type: selectedFile.type || 'application/pdf',
        data: reader.result
      });
      reader.onerror = () => {
        window.alert('Não foi possível ler o arquivo selecionado.');
      };
      reader.readAsDataURL(selectedFile);
      return;
    }

    finishSave(existingNotice?.attachment || null);
  });

  if (noticeList) {
    noticeList.addEventListener('click', async event => {
      if (currentRole !== 'professor') return;

      const editButton = event.target.closest('[data-edit]');
      if (editButton) {
        const notice = notices.find(item => String(item.id) === editButton.dataset.edit);
        if (!notice) return;

        editingNoticeId = notice.id;
        document.querySelector('#notice-title').value = notice.title;
        document.querySelector('#notice-content').value = notice.content;
        document.querySelector('#notice-author').value = notice.author;
        document.querySelector('#notice-category').value = notice.category;
        const selectedAudience = new Set(
          notice.audience?.length
            ? notice.audience.map(target => `${target.serie}::${target.turma}`)
            : (notice.series?.length ? notice.series : ['1º ano', '2º ano', '3º ano'])
              .flatMap(serie => noticeCourses.map(turma => `${serie}::${turma}`))
        );
        document.querySelectorAll('[name="audience"]').forEach(input => {
          input.checked = selectedAudience.has(input.value);
        });
        document.querySelector('#notice-subject').value = notice.subject || '';
        updateSubjectField();
        document.querySelector('#notice-due-date').value = notice.dueDate || '';
        document.querySelector('[name="pinned"]').checked = notice.pinned;
        document.querySelector('#modal-eyebrow').textContent = 'alterar comunicado';
        document.querySelector('#modal-title').textContent = 'Editar aviso';
        document.querySelector('#submit-notice').firstChild.textContent = 'Salvar alterações ';
        modal.showModal();
        document.querySelector('#notice-title').focus();
        return;
      }

      const button = event.target.closest('[data-delete]');
      if (!button || !window.confirm('Excluir este aviso?')) return;

      try {
        await requestApi(`/api/avisos/${button.dataset.delete}`, { method: 'DELETE' });
        notices = notices.filter(notice => String(notice.id) !== button.dataset.delete);
        renderNotices();
      } catch (error) {
        console.error('Não foi possível excluir o aviso:', error);
        window.alert(error.message);
      }
    });
  }

  const loggedUser = document.querySelector('#logged-user');
  if (loggedUser) {
    loggedUser.addEventListener('click', () => profileDialog.showModal());
  }

  const closeProfileButton = document.querySelector('#close-profile');
  if (closeProfileButton) {
    closeProfileButton.addEventListener('click', () => profileDialog.close());
  }

  if (profileDialog) {
    profileDialog.addEventListener('click', event => {
      if (event.target === profileDialog) profileDialog.close();
    });
  }
}

attachEventHandlers();

if (noticeList && emptyState) {
  loadNotices();
}

if (calendarList && calendarEmpty) {
  loadCalendarEvents();
}
