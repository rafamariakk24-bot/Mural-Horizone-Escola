const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { test } = require('node:test');

const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'mural-database-test-'));
process.env.MURAL_DATABASE_PATH = path.join(temporaryDirectory, 'mural-test.db');

const mural = require('../src/database/mural');

test('grava, consulta e remove avisos no SQLite', async () => {
  try {
    await mural.initialize();

    const notice = await mural.create({
      title: 'Teste de conexão SQLite',
      content: 'Confirma que o banco aceita gravação e leitura.',
      author: 'Teste automatizado',
      category: 'Importante',
      audience: [{ serie: '1º ano', turma: 'Alimentos' }]
    });

    assert.ok(notice.id > 0);
    assert.equal(notice.title, 'Teste de conexão SQLite');
    assert.deepEqual(notice.audience, [{ serie: '1º ano', turma: 'Alimentos' }]);

    const savedNotices = await mural.list();
    assert.ok(savedNotices.some(savedNotice => savedNotice.id === notice.id));

    assert.equal(await mural.remove(notice.id), true);
    const remainingNotices = await mural.list();
    assert.ok(!remainingNotices.some(savedNotice => savedNotice.id === notice.id));
  } finally {
    await mural.close();
    fs.rmSync(temporaryDirectory, { recursive: true, force: true });
  }
});
