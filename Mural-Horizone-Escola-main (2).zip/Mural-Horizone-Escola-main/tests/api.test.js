const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { test } = require('node:test');
const express = require('express');

const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'mural-api-test-'));
process.env.MURAL_DATABASE_PATH = path.join(temporaryDirectory, 'mural-api-test.db');

const app = require('../index');
const atendimentoRoutes = require('../src/routes/atendimentoRoute');
const mural = require('../src/database/mural');

test('rotas de atendimento carregam e aceitam o caminho correto de exclusão', async () => {
  const atendimentoApp = express();
  atendimentoApp.use(atendimentoRoutes);
  const server = atendimentoApp.listen(0);

  try {
    await new Promise((resolve, reject) => {
      server.once('listening', resolve);
      server.once('error', reject);
    });

    const response = await fetch(`http://127.0.0.1:${server.address().port}/atendimento/42`, {
      method: 'DELETE'
    });

    assert.equal(response.status, 200);
    assert.match(await response.text(), /excluindo o atendimento/);
  } finally {
    await new Promise((resolve, reject) => {
      server.close(error => error ? reject(error) : resolve());
    });
  }
});

test('API inicializa, conecta ao banco e executa CRUD de avisos', async () => {
  let server;

  try {
    await mural.initialize();
    server = app.listen(0);
    await new Promise((resolve, reject) => {
      server.once('listening', resolve);
      server.once('error', reject);
    });

    const baseUrl = `http://127.0.0.1:${server.address().port}`;

    const rootResponse = await fetch(baseUrl, { redirect: 'manual' });
    assert.equal(rootResponse.status, 302);
    assert.equal(rootResponse.headers.get('location'), '/mural/');

    const muralHomeResponse = await fetch(`${baseUrl}/mural/`);
    assert.equal(muralHomeResponse.status, 200);
    assert.match(await muralHomeResponse.text(), /id="login-form"/);

    const loginPageResponse = await fetch(`${baseUrl}/mural/login.html`);
    assert.equal(loginPageResponse.status, 200);
    const loginPage = await loginPageResponse.text();
    assert.match(loginPage, /@professor\.edu\.pi\.gov\.br/);
    assert.match(loginPage, /<option value="professor">Professor\(a\)<\/option>/);
    assert.match(loginPage, /<b>Professor\(a\):<\/b>/);
    assert.match(loginPage, /name="teacherSeries"/);
    const styleResponse = await fetch(`${baseUrl}/mural/assets/styles.css`);
    assert.equal(styleResponse.status, 200);
    const scriptResponse = await fetch(`${baseUrl}/mural/assets/app.js`);
    assert.equal(scriptResponse.status, 200);

    const muralPageResponse = await fetch(`${baseUrl}/mural/mural.html`);
    assert.equal(muralPageResponse.status, 200);
    const muralPage = await muralPageResponse.text();
    assert.match(muralPage, /id="profile-teacher-type"/);
    assert.match(muralPage, /id="profile-subject"/);
    assert.match(muralPage, /id="profile-courses"/);
    assert.match(muralPage, /id="profile-teacher-series"/);
    assert.match(muralPage, /<span>Turma\(s\)<\/span>/);
    const legacyLoginResponse = await fetch(`${baseUrl}/mural/rafa.html`);
    assert.equal(legacyLoginResponse.status, 200);
    assert.match(await legacyLoginResponse.text(), /id="login-form"/);
    const legacyMuralResponse = await fetch(`${baseUrl}/mural/rafa1.html`);
    assert.equal(legacyMuralResponse.status, 200);
    assert.match(await legacyMuralResponse.text(), /id="profile-teacher-type"/);

    const healthResponse = await fetch(`${baseUrl}/api/health`);
    assert.equal(healthResponse.status, 200);
    assert.deepEqual(await healthResponse.json(), { status: 'ok', database: 'connected' });

    const professorEmail = 'professora.teste@professor.edu.pi.gov.br';
    const professorProfileUrl = `${baseUrl}/api/professores/${encodeURIComponent(professorEmail)}/materia`;
    const initialProfileResponse = await fetch(professorProfileUrl);
    assert.equal(initialProfileResponse.status, 200);
    assert.equal((await initialProfileResponse.json()).subject, '');
    const emptySubjectResponse = await fetch(professorProfileUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject: '' })
    });
    assert.equal(emptySubjectResponse.status, 200);
    assert.equal((await emptySubjectResponse.json()).subject, '');

    const professorCoursesUrl = `${baseUrl}/api/professores/${encodeURIComponent(professorEmail)}/cursos`;
    const initialCoursesResponse = await fetch(professorCoursesUrl);
    assert.equal(initialCoursesResponse.status, 200);
    assert.deepEqual((await initialCoursesResponse.json()).courses, []);

    const professorSeriesUrl = `${baseUrl}/api/professores/${encodeURIComponent(professorEmail)}/series`;
    const initialSeriesResponse = await fetch(professorSeriesUrl);
    assert.equal(initialSeriesResponse.status, 200);
    assert.deepEqual((await initialSeriesResponse.json()).series, []);

    const saveProfessorSubjectResponse = await fetch(professorProfileUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject: 'Matemática, Física, matemática' })
    });
    assert.equal(saveProfessorSubjectResponse.status, 200);
    assert.equal((await saveProfessorSubjectResponse.json()).subject, 'Matemática, Física');

    const saveProfessorCoursesResponse = await fetch(professorCoursesUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ courses: ['Desenvolvimento de Sistemas', 'Farmácia'] })
    });
    assert.equal(saveProfessorCoursesResponse.status, 200);
    assert.deepEqual(
      (await saveProfessorCoursesResponse.json()).courses,
      ['Desenvolvimento de Sistemas', 'Farmácia']
    );

    const saveProfessorSeriesResponse = await fetch(professorSeriesUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ series: ['1º ano', '2º ano'] })
    });
    assert.equal(saveProfessorSeriesResponse.status, 200);
    assert.deepEqual((await saveProfessorSeriesResponse.json()).series, ['1º ano', '2º ano']);

    const invalidProfessorSeriesResponse = await fetch(professorSeriesUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ series: ['1º ano', '1º ano'] })
    });
    assert.equal(invalidProfessorSeriesResponse.status, 400);

    const invalidProfessorCoursesResponse = await fetch(professorCoursesUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ courses: ['Alimentos', 'Alimentos'] })
    });
    assert.equal(invalidProfessorCoursesResponse.status, 400);

    const wrongCourseNoticeResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso para curso não vinculado',
        content: 'O envio deve ser recusado.',
        author: `Professora: ${professorEmail}`,
        teacherEmail: professorEmail,
        category: 'Importante',
        audience: [{ serie: '1º ano', turma: 'Alimentos' }]
      })
    });
    assert.equal(wrongCourseNoticeResponse.status, 403);

    const wrongSeriesNoticeResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso para série não vinculada',
        content: 'O envio deve ser recusado.',
        author: `Professora: ${professorEmail}`,
        teacherEmail: professorEmail,
        category: 'Importante',
        audience: [{ serie: '3º ano', turma: 'Desenvolvimento de Sistemas' }]
      })
    });
    assert.equal(wrongSeriesNoticeResponse.status, 403);

    const createProfessorNoticeResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso de Matemática',
        content: 'Conteúdo da avaliação.',
        author: `Professora: ${professorEmail}`,
        teacherEmail: professorEmail,
        teacherSubject: 'Matemática, Física',
        category: 'Prova',
        audience: [
          { serie: '1º ano', turma: 'Desenvolvimento de Sistemas' },
          { serie: '2º ano', turma: 'Farmácia' }
        ],
        subject: 'Equações'
      })
    });
    assert.equal(createProfessorNoticeResponse.status, 201);
    const professorNotice = await createProfessorNoticeResponse.json();
    assert.equal(professorNotice.teacherSubject, 'Matemática, Física');
    assert.deepEqual(professorNotice.audience, [
      { serie: '1º ano', turma: 'Desenvolvimento de Sistemas' },
      { serie: '2º ano', turma: 'Farmácia' }
    ]);

    const updateWrongSeriesNoticeResponse = await fetch(`${baseUrl}/api/avisos/${professorNotice.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso atualizado',
        content: 'A série não vinculada deve ser recusada.',
        author: `Professora: ${professorEmail}`,
        teacherEmail: professorEmail,
        category: 'Importante',
        audience: [{ serie: '3º ano', turma: 'Desenvolvimento de Sistemas' }]
      })
    });
    assert.equal(updateWrongSeriesNoticeResponse.status, 403);

    const createSecondYearNoticeResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso somente para o segundo ano',
        content: 'Conteúdo direcionado.',
        author: 'Teste automatizado',
        category: 'Importante',
        audience: [{ serie: '2º ano', turma: 'Alimentos' }]
      })
    });
    assert.equal(createSecondYearNoticeResponse.status, 201);
    const secondYearNotice = await createSecondYearNoticeResponse.json();

    const firstYearNoticesResponse = await fetch(`${baseUrl}/api/avisos?role=aluno&serie=${encodeURIComponent('1º ano')}&turma=${encodeURIComponent('Desenvolvimento de Sistemas')}`);
    assert.equal(firstYearNoticesResponse.status, 200);
    const firstYearNotices = await firstYearNoticesResponse.json();
    assert.ok(firstYearNotices.some(notice => notice.id === professorNotice.id));
    assert.ok(!firstYearNotices.some(notice => notice.id === secondYearNotice.id));

    const firstYearAlimentosResponse = await fetch(`${baseUrl}/api/avisos?role=aluno&serie=${encodeURIComponent('1º ano')}&turma=${encodeURIComponent('Alimentos')}`);
    assert.equal(firstYearAlimentosResponse.status, 200);
    const firstYearAlimentos = await firstYearAlimentosResponse.json();
    assert.ok(!firstYearAlimentos.some(notice => notice.id === professorNotice.id));
    assert.ok(!firstYearAlimentos.some(notice => notice.id === secondYearNotice.id));

    const secondYearNoticesResponse = await fetch(`${baseUrl}/api/avisos?role=aluno&serie=${encodeURIComponent('2º ano')}&turma=${encodeURIComponent('Alimentos')}`);
    assert.equal(secondYearNoticesResponse.status, 200);
    const secondYearNotices = await secondYearNoticesResponse.json();
    assert.ok(secondYearNotices.some(notice => notice.id === secondYearNotice.id));
    assert.ok(!secondYearNotices.some(notice => notice.id === professorNotice.id));

    const secondYearFarmaciaResponse = await fetch(`${baseUrl}/api/avisos?role=aluno&serie=${encodeURIComponent('2º ano')}&turma=${encodeURIComponent('Farmácia')}`);
    assert.equal(secondYearFarmaciaResponse.status, 200);
    const secondYearFarmacia = await secondYearFarmaciaResponse.json();
    assert.ok(secondYearFarmacia.some(notice => notice.id === professorNotice.id));

    const secondYearDevelopmentResponse = await fetch(`${baseUrl}/api/avisos?role=aluno&serie=${encodeURIComponent('2º ano')}&turma=${encodeURIComponent('Desenvolvimento de Sistemas')}`);
    assert.equal(secondYearDevelopmentResponse.status, 200);
    const secondYearDevelopment = await secondYearDevelopmentResponse.json();
    assert.ok(!secondYearDevelopment.some(notice => notice.id === secondYearNotice.id));

    const wrongCourseUpdateResponse = await fetch(`${baseUrl}/api/avisos/${professorNotice.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: professorNotice.title,
        content: professorNotice.content,
        author: professorNotice.author,
        teacherEmail: professorEmail,
        category: professorNotice.category,
        audience: [{ serie: '1º ano', turma: 'Alimentos' }],
        subject: professorNotice.subject
      })
    });
    assert.equal(wrongCourseUpdateResponse.status, 403);

    const teacherNoticesResponse = await fetch(`${baseUrl}/api/avisos?role=professor`);
    assert.equal(teacherNoticesResponse.status, 200);
    const teacherNotices = await teacherNoticesResponse.json();
    assert.ok(teacherNotices.some(notice => notice.id === professorNotice.id));
    assert.ok(teacherNotices.some(notice => notice.id === secondYearNotice.id));

    const invalidSeriesResponse = await fetch(`${baseUrl}/api/avisos?role=aluno&serie=4%C2%BA%20ano&turma=Alimentos`);
    assert.equal(invalidSeriesResponse.status, 400);
    const invalidCourseResponse = await fetch(`${baseUrl}/api/avisos?role=aluno&serie=${encodeURIComponent('1º ano')}&turma=Informática`);
    assert.equal(invalidCourseResponse.status, 400);

    const missingNoticeSeriesResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso sem série',
        content: 'O envio deve ser recusado.',
        author: 'Teste automatizado',
        category: 'Importante',
        audience: []
      })
    });
    assert.equal(missingNoticeSeriesResponse.status, 400);

    const invalidNoticeAudienceResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso para curso inválido',
        content: 'O envio deve ser recusado.',
        author: 'Teste automatizado',
        category: 'Importante',
        audience: [{ serie: '1º ano', turma: 'Informática' }]
      })
    });
    assert.equal(invalidNoticeAudienceResponse.status, 400);

    const updateProfessorSubjectResponse = await fetch(professorProfileUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject: 'Física, Química' })
    });
    assert.equal(updateProfessorSubjectResponse.status, 200);
    assert.equal((await updateProfessorSubjectResponse.json()).subject, 'Física, Química');
    const refreshedProfessorNoticeResponse = await fetch(`${baseUrl}/api/avisos`);
    const refreshedProfessorNotices = await refreshedProfessorNoticeResponse.json();
    assert.equal(
      refreshedProfessorNotices.find(notice => notice.id === professorNotice.id).teacherSubject,
      'Física, Química'
    );

    const invalidProfessorSubjectResponse = await fetch(professorProfileUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject: 'Matemática, ' + 'X'.repeat(81) })
    });
    assert.equal(invalidProfessorSubjectResponse.status, 400);

    const deleteProfessorNoticeResponse = await fetch(`${baseUrl}/api/avisos/${professorNotice.id}`, {
      method: 'DELETE'
    });
    assert.equal(deleteProfessorNoticeResponse.status, 204);
    const deleteSecondYearNoticeResponse = await fetch(`${baseUrl}/api/avisos/${secondYearNotice.id}`, {
      method: 'DELETE'
    });
    assert.equal(deleteSecondYearNoticeResponse.status, 204);

    const eventDate = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const createEventResponse = await fetch(`${baseUrl}/api/eventos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Reunião de teste',
        date: eventDate,
        time: '14:30',
        location: 'Auditório'
      })
    });
    assert.equal(createEventResponse.status, 201);
    const createdEvent = await createEventResponse.json();
    assert.ok(createdEvent.id > 0);
    assert.equal(createdEvent.date, eventDate);
    assert.equal(createdEvent.time, '14:30');
    assert.equal(createdEvent.location, 'Auditório');

    const eventsResponse = await fetch(`${baseUrl}/api/eventos`);
    assert.equal(eventsResponse.status, 200);
    assert.ok((await eventsResponse.json()).some(event => event.id === createdEvent.id));

    const invalidEventResponse = await fetch(`${baseUrl}/api/eventos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Data impossível', date: '2026-02-31' })
    });
    assert.equal(invalidEventResponse.status, 400);

    const deleteEventResponse = await fetch(`${baseUrl}/api/eventos/${createdEvent.id}`, {
      method: 'DELETE'
    });
    assert.equal(deleteEventResponse.status, 204);

    const listResponse = await fetch(`${baseUrl}/api/avisos`);
    assert.equal(listResponse.status, 200);
    assert.ok(Array.isArray(await listResponse.json()));

    const createResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Teste da API',
        content: 'Aviso criado pelo teste de integração.',
        author: 'Teste automatizado',
        category: 'Importante',
        audience: [{ serie: '1º ano', turma: 'Alimentos' }]
      })
    });
    assert.equal(createResponse.status, 201);
    const createdNotice = await createResponse.json();
    assert.ok(createdNotice.id > 0);

    const assessmentCreateResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Prova de teste',
        content: 'Aviso sobre a prova.',
        author: 'Teste automatizado',
        category: 'Prova',
        audience: [{ serie: '1º ano', turma: 'Alimentos' }],
        subject: 'Conteúdo original'
      })
    });
    assert.equal(assessmentCreateResponse.status, 201);
    const assessmentNotice = await assessmentCreateResponse.json();
    assert.equal(assessmentNotice.subject, 'Conteúdo original');

    const assessmentUpdateResponse = await fetch(`${baseUrl}/api/avisos/${assessmentNotice.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso do ENEM atualizado',
        content: 'Conteúdo atualizado pela professora.',
        author: 'Teste automatizado',
        category: 'ENEM',
        audience: [
          { serie: '1º ano', turma: 'Alimentos' },
          { serie: '2º ano', turma: 'Farmácia' }
        ],
        subject: 'Linguagens e Ciências Humanas'
      })
    });
    assert.equal(assessmentUpdateResponse.status, 200);
    const updatedAssessmentNotice = await assessmentUpdateResponse.json();
    assert.equal(updatedAssessmentNotice.category, 'ENEM');
    assert.equal(updatedAssessmentNotice.subject, 'Linguagens e Ciências Humanas');
    assert.deepEqual(updatedAssessmentNotice.audience, [
      { serie: '1º ano', turma: 'Alimentos' },
      { serie: '2º ano', turma: 'Farmácia' }
    ]);

    const missingAssessmentSubject = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Prova sem conteúdo',
        content: 'Esse envio deve ser recusado.',
        author: 'Teste automatizado',
        category: 'Prova',
        audience: [{ serie: '1º ano', turma: 'Alimentos' }]
      })
    });
    assert.equal(missingAssessmentSubject.status, 400);

    const updateResponse = await fetch(`${baseUrl}/api/avisos/${createdNotice.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Aviso atualizado',
        content: 'Conteúdo atualizado pelo teste.',
        author: 'Teste automatizado',
        category: 'Importante',
        audience: [{ serie: '3º ano', turma: 'Farmácia' }]
      })
    });
    assert.equal(updateResponse.status, 200);
    const updatedNotice = await updateResponse.json();
    assert.equal(updatedNotice.title, 'Aviso atualizado');
    assert.deepEqual(updatedNotice.audience, [{ serie: '3º ano', turma: 'Farmácia' }]);

    const deleteResponse = await fetch(`${baseUrl}/api/avisos/${createdNotice.id}`, {
      method: 'DELETE'
    });
    assert.equal(deleteResponse.status, 204);
    const deleteAssessmentResponse = await fetch(`${baseUrl}/api/avisos/${assessmentNotice.id}`, {
      method: 'DELETE'
    });
    assert.equal(deleteAssessmentResponse.status, 204);

    const invalidResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Aviso incompleto' })
    });
    assert.equal(invalidResponse.status, 400);

    const malformedResponse = await fetch(`${baseUrl}/api/avisos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{'
    });
    assert.equal(malformedResponse.status, 400);
    assert.deepEqual(await malformedResponse.json(), { error: 'O JSON enviado é inválido.' });
  } finally {
    if (server) {
      await new Promise((resolve, reject) => {
        server.close(error => error ? reject(error) : resolve());
      });
    }

    await mural.close();
    fs.rmSync(temporaryDirectory, { recursive: true, force: true });
  }
});
