const express = require('express');
const path = require('node:path');
const muralRoutes = require('./src/routes');
const mural = require('./src/database/mural');

const app = express();
const port = Number(process.env.PORT) || 3120;
const muralDirectory = path.join(__dirname, 'public');

app.use(express.json({ limit: '3mb' }));
app.use(muralRoutes);

app.get('/mural', (req, res) => {
  res.sendFile(path.join(muralDirectory, 'rafa.html'));
});
app.get('/mural/rafa.html', (req, res) => {
  res.sendFile(path.join(muralDirectory, 'rafa.html'));
});
app.get('/mural/login.html', (req, res) => {
  res.sendFile(path.join(muralDirectory, 'rafa.html'));
});
app.get('/mural/rafa1.html', (req, res) => {
  res.sendFile(path.join(muralDirectory, 'mural.html'));
});
app.use('/mural', express.static(muralDirectory));
app.get('/', (req, res) => {
  res.redirect('/mural/');
});

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);

  const status = error.status === 413 ? 413 : error.status === 400 ? 400 : 500;
  if (status >= 500) console.error('Erro ao processar a requisição:', error);
  const message = status === 413
    ? 'O conteúdo enviado excede o limite permitido.'
    : status === 400
      ? 'O JSON enviado é inválido.'
      : 'Ocorreu um erro interno ao processar a requisição.';
  res.status(status).json({ error: message });
});

if (require.main === module) {
  mural.initialize()
    .then(() => {
      const server = app.listen(port, () => {
        console.log(`Servidor rodando em http://localhost:${port}/mural/`);
      });

      server.on('error', error => {
        console.error('Não foi possível iniciar o servidor:', error);
        process.exitCode = 1;
      });
    })
    .catch(error => {
      console.error('Não foi possível iniciar o banco do mural:', error);
      process.exitCode = 1;
    });
}

module.exports = app;
